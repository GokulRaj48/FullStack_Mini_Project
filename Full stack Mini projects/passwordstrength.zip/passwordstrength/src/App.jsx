import React, { useState } from 'react';
// import './App.css'; // Import CSS file for styling

function PasswordStrengthIndicator() {
  const [password, setPassword] = useState("");
  const [strength, setStrength] = useState("");

  // Function to evaluate password strength
  function evaluatePasswordStrength(password) {
    let score = 0;

    if (!password) return '';

    // Check password length
    if (password.length > 8) score += 1;
    // Contains lowercase
    if (/[a-z]/.test(password)) score += 1;
    // Contains uppercase
    if (/[A-Z]/.test(password)) score += 1;
    // Contains numbers
    if (/\d/.test(password)) score += 1;
    // Contains special characters
    if (/[^A-Za-z0-9]/.test(password)) score += 1;

    switch (score) {
      case 0:
      case 1:
      case 2:
        return "Weak";
      case 3:
        return "Medium";
      case 4:
      case 5:
        return "Strong";
      default:
        return "";
    }
  }

  return (
    <div className="password-container">
      <input
        type="password"
        placeholder="Enter your password"
        value={password}
        onChange={(event) => {
          setPassword(event.target.value);
          setStrength(evaluatePasswordStrength(event.target.value));
        }}
      />
      <div className="strength-indicator">
        <div className={`strength ${strength.toLowerCase()}`}></div>
        <small>Password strength: {strength}</small>
      </div>
    </div>
  );
}

export default PasswordStrengthIndicator;
